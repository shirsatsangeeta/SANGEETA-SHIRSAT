﻿Module Module1
    Sub Main()
        Console.Write("Enter a non-negative integer (n): ")
        Dim n As Integer
        If Integer.TryParse(Console.ReadLine(), n) AndAlso n >= 0 Then
            Console.WriteLine("The sum of the first " & n & " natural numbers is: " & SumOfNaturalNumbers(n))
        Else
            Console.WriteLine("Invalid input. Please enter a non-negative integer.")
        End If
        Console.ReadLine()
    End Sub
    Private Function SumOfNaturalNumbers(ByVal n As Integer) As Integer
        If n = 1 Then
            Return 1
        Else
            Return n + SumOfNaturalNumbers(n - 1)
        End If
    End Function
End Module
