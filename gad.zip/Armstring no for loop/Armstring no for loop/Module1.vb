﻿Module Module1
    Sub Main()
        Dim num, sum, remainder, originalNum As Integer
        Console.WriteLine("Armstrong numbers between 1 and 500:")
        For num = 1 To 500
            sum = 0
            originalNum = num
            While originalNum <> 0
                remainder = originalNum Mod 10
                sum += remainder * remainder * remainder
                originalNum \= 10
            End While
            If num = sum Then
                Console.WriteLine(num)
            End If
        Next
        Console.ReadLine()
    End Sub
End Module
