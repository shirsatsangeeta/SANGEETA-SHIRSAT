﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Val(TextBox1.Text) Mod 2 = 0 Then
            TextBox2.Text = "Even No.."
        Else
            TextBox2.Text = "Odd No.."
        End If
    End Sub
End Class
