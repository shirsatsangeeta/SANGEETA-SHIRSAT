﻿Module Module1

    Sub Main()
        Dim n As Integer
        Console.Write("Enter The No: ")
        n = Val(Console.ReadLine())
        If n < 0 Then
            Console.Write("The Entered No is Less then '0' :")
        Else

            If n Mod 2 = 0 Then
                Console.Write("Even No: ")
            Else
                Console.Write("Odd no: ")
            End If
        End If
        Console.ReadLine()
    End Sub

End Module
