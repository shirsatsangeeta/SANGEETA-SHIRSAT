﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Val(TextBox1.Text) > Val(TextBox2.Text) And Val(TextBox1.Text) > Val(TextBox3.Text) Then
            Label5.Text = Val(TextBox1.Text)
        ElseIf Val(TextBox2.Text) > Val(TextBox3.Text) Then
            Label5.Text = Val(TextBox2.Text)
        Else
            Label5.Text = Val(TextBox3.Text)
        End If
    End Sub
End Class
