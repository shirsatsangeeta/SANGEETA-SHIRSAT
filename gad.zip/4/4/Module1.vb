﻿Module Module1
    Sub Main(args As String())
        Console.Write("Please enter a whole number: ")
        Dim number As Integer
        If Integer.TryParse(Console.ReadLine(), number) Then
            Dim result As Decimal = Math.Round(number / 3D, 3)
            Dim formattedResult As String = result.ToString("#,##0.000")
            Console.WriteLine("Result of division: " & formattedResult)
        Else
            Console.WriteLine("Invalid input. Please enter a valid whole number.")
        End If
    End Sub
End Module
