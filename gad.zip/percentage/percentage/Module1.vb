﻿Module Module1

    Sub Main()
        Dim percentage As Double
        Console.WriteLine("          Percentage:         ")
        Console.ReadLine()
        Console.WriteLine("Enter your percentage:")
        percentage = Double.Parse(Console.ReadLine())

        If percentage < 40 Then
            Console.WriteLine("Result: Fail")
        ElseIf percentage >= 40 And percentage < 60 Then
            Console.WriteLine("Result: Pass Class")
        ElseIf percentage >= 60 And percentage < 75 Then
            Console.WriteLine("Result: First Class")
        Else
            Console.WriteLine("Result: Distinction")
        End If
        Console.ReadLine()
    End Sub

End Module
