﻿Public Class Form1


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If (Val(TextBox2.Text) = 0) Then
            TextBox3.Text = "Division is not Possible."

        Else
            TextBox3.Text = Val(TextBox1.Text) / Val(TextBox2.Text)
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox3.Text = Val(TextBox1.Text) + Val(TextBox2.Text)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox3.Text = Val(TextBox1.Text) - Val(TextBox2.Text)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox3.Text = Val(TextBox1.Text) * Val(TextBox2.Text)
    End Sub
End Class
