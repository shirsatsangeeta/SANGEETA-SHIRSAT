﻿Module Module1

    Sub Main()
        Console.Write("Elegible For Voting / Driving:")
        Console.ReadLine()
        Dim Name As String
        Dim Age As Integer
        Console.Write("Enter the Name:")
        Name = (Console.ReadLine)
        Console.Write("Enter the Age:")
        Age = Val(Console.ReadLine)
        If Age < 18 Then
            Console.Write(Name & " is Not Elegible For Voting As well as For Driving.")
        Else
            Console.Write(Name & " is Elegible For Voting As well as For Driving.")
        End If
        Console.ReadLine()
    End Sub

End Module
