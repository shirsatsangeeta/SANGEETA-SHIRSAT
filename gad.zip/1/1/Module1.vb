﻿Module Module1
    Sub Main(args As String())
        Console.WriteLine("Hello Coursera")
        Console.ReadLine()
    End Sub
End Module
