﻿Module Module1
    Sub Main()
        ' Example usage of the SimpleFunction
        Dim result As Integer = SimpleFunction()
        Console.WriteLine("Result of SimpleFunction: " & result)

        ' Example usage of the ParameterizedFunction
        Dim number1 As Integer = 10
        Dim number2 As Integer = 5
        Dim sum As Integer = ParameterizedFunction(number1, number2)
        Console.WriteLine("Result of ParameterizedFunction: " & sum)

        Console.ReadLine()
    End Sub

    ' Simple function that returns a fixed value
    Function SimpleFunction() As Integer
        Return 42
    End Function

    ' Parameterized function that takes two integers as input parameters and returns their sum
    Function ParameterizedFunction(ByVal num1 As Integer, ByVal num2 As Integer) As Integer
        Return num1 + num2
    End Function
End Module
