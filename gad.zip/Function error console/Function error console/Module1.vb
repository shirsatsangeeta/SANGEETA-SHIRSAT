﻿Module Module1

    Sub Main()

    End Sub
    Function FindMax(ByVal num1 As Integer, ByVal num2 As Integer)As
        Dim result As Integer
        If (num1 > num2) Then
            result = num1
        Else
            result = num2
        End If
        FindMax = result
    End Function

End Module
