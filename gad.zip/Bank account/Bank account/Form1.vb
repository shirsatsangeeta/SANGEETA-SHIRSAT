﻿Public Class Form1
    Private balance As Decimal = 0

    Private Sub DepositButton_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Deposit(Val(TextBox1.Text()))
    End Sub

    Private Sub WithdrawButton_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Withdraw(Val(TextBox2.Text()))
    End Sub

    Private Sub Deposit(amountText As Decimal)
        Dim depositAmount As Decimal = amountText
        balance += depositAmount
        TextBox3.Text = balance
        MessageBox.Show("Deposit of $" & depositAmount & " successful. New balance: $" & balance)
    End Sub

    Private Sub Withdraw(amountText As Decimal)
        Dim withdrawAmount As Decimal = amountText
        If withdrawAmount <= balance Then
            balance -= withdrawAmount
            TextBox3.Text = balance
            MessageBox.Show("Withdrawal of $" & withdrawAmount & " successful. New balance: $" & balance)
        Else
            MessageBox.Show("Insufficient funds")
        End If
    End Sub

  
End Class
