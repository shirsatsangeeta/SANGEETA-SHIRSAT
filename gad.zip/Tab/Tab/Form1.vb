﻿Public Class Form1

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim selectedItems As String = ComboBox1.SelectedItem.ToString()
        Select Case selectedItems
            Case "Computer Engineering."
                Label10.Text = "Diploma In Computer Engineering."
            Case "Electronics and Telecommunication Engineering."
                Label10.Text = "Diploma In Electronics and" & Environment.NewLine & " Telecommunication Engineering."
            Case "Information Technology."
                Label10.Text = "Diploma In Information Technology."
        End Select
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "vinay.more" AndAlso TextBox2.Text = "admin" Then
            Label6.Text = "Successful"
            Dim myInteger As Integer = 0
            TextBox1.Text = ""
            TextBox2.Text = ""
        Else
            Label6.Text = "Invalid username or password"
        End If
    End Sub
    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        Dim selectedItem As String = ComboBox2.SelectedItem.ToString()
        Select Case selectedItem
            Case "GAD"
                TextBox3.Text = "22034 - GUI Application Development Using VB.Net.pdf"
            Case "JPR"
                TextBox3.Text = "22412 - Java Programming.pdf"
            Case "DCC"
                TextBox3.Text = "22414 - Data Communication and Computer Network.pdf"
            Case "MIC"
                TextBox3.Text = "22415 - Microprocessors.pdf"
            Case "SEN"
                TextBox3.Text = "22413 - Software Enginering.pdf"
        End Select
    End Sub
End Class
