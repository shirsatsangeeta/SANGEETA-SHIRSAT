﻿Imports System.Text.RegularExpressions

Public Class Form1
   

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim mobilePattern As String = "^\d{10}$" ' Regular expression pattern for 10-digit mobile number
        Dim emailPattern As String = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$" ' Regular expression pattern for email ID

        Dim mobileNumber As String = Val(TextBox1.Text())
        Dim email As String = TextBox2.Text.Trim()

        ' Clear any previous error messages
        ErrorProvider1.Clear()

        ' Validate mobile number
        If String.IsNullOrWhiteSpace(mobileNumber) Then
            ErrorProvider1.SetError(TextBox1, "Mobile number cannot be empty")
        ElseIf Not Regex.IsMatch(mobileNumber, mobilePattern) Then
            ErrorProvider1.SetError(TextBox1, "Invalid mobile number")
        End If

        ' Validate email
        If String.IsNullOrWhiteSpace(email) Then
            ErrorProvider1.SetError(TextBox2, "Email cannot be empty")
        ElseIf Not Regex.IsMatch(email, emailPattern) Then
            ErrorProvider1.SetError(TextBox2, "Invalid email")
        End If

        ' Check if both mobile number and email are valid
        If Not ErrorProvider1.GetError(TextBox1) = "" OrElse Not ErrorProvider1.GetError(TextBox2) = "" Then
            ' At least one of them is invalid
            MessageBox.Show("Please correct the errors and try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            ' Both are valid
            MessageBox.Show("Validation successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub


End Class
