﻿Public Class Vehicle
    Public Property Make As String
    Public Property Model As String
    Public Property Year As Integer
    Public Sub New(make As String, model As String, year As Integer)
        Me.Make = make
        Me.Model = model
        Me.Year = year
    End Sub

    Public Overridable Sub Display()
        Console.WriteLine("Make : " & Make & ", Model : " & Model & ", Year : " & Year)
    End Sub
End Class
Public Class Car
    Inherits Vehicle
    Public Property Color As String
    Public Property NumberOfDoors As Integer

    Public Sub New(make As String, model As String, year As Integer, color As String, numberOfDoors As Integer)
        MyBase.New(make, model, year)
        Me.Color = color
        Me.NumberOfDoors = numberOfDoors
    End Sub

    Public Overrides Sub Display()
        MyBase.Display()
        Console.WriteLine("Color: " & Color & ",  Number of Doors: " & NumberOfDoors)
    End Sub
End Class

Module Module1
    Sub Main(args As String())
        Dim vehicle As New Vehicle("Toyota", "Camry", 2022)
        Dim car As New Car("Ford", "Mustang", 2023, "Red", 2)
        Console.WriteLine("Vehicle Information:")
        vehicle.Display()
        Console.WriteLine("Car Information:")
        car.Display()
        Console.ReadLine()
    End Sub
End Module