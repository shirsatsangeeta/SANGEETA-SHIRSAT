﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim n, num1, num2, num3, i As Integer
        n = Val(TextBox1.Text)
        i = 0
        num1 = 0
        num2 = 1
        Label3.Text = "0, 1" ' Initialize Label3 with the first two Fibonacci numbers
        While (i < n - 1)
            num3 = num1 + num2
            Label3.Text &= ", " & num3 ' Append the new Fibonacci number to the existing text
            num1 = num2
            num2 = num3
            i = i + 1
        End While
    End Sub
End Class
