﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label1.TextAlign = HorizontalAlignment.Center
        Label1.Text = TextBox1.Text
    End Sub
End Class
