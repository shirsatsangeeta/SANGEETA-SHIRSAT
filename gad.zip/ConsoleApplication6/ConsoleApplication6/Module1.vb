﻿Imports System.Console
Public Class ConstDest
    Public Sub New()
        Console.WriteLine("Constructor called. Object created.")
    End Sub
    Protected Overrides Sub Finalize()
        Console.WriteLine("Destructor called. Object destroyed.")
        MyBase.Finalize()
        ReadLine()
    End Sub
End Class

Module Module1
    Sub Main(args As String())
        Dim myObject As New ConstDest()
        Console.WriteLine("Performing some operations...")
        Threading.Thread.Sleep(2000)
        Console.WriteLine("Exiting the program.")
    End Sub
End Module
