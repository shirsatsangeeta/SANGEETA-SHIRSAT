﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim selectedSubjects As String = "Selected Subjects:" & vbCrLf
        For Each subject As Object In ListBox1.SelectedItems
            selectedSubjects &= subject.ToString() & vbCrLf
        Next
        MessageBox.Show(selectedSubjects)
    End Sub
End Class
