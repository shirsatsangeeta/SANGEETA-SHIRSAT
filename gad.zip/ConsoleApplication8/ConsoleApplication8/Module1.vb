﻿Public Class Person
    Public FirstName As String
    Public LastName As String
    Public DateOfBirth As Date
    Public Gender As String

    Public ReadOnly Property FullName() As String
        Get
            Return FirstName & " " & LastName
        End Get
    End Property
End Class

Public Class Customer
    Inherits Person

    Public CustomerID As String
End Class

Module Module1
    Sub Main()
        Dim person As New Person()
        person.FirstName = "John"
        person.LastName = "Doe"
        person.DateOfBirth = New Date(1990, 5, 15)
        person.Gender = "Male"

        Dim customer As New Customer()
        customer.FirstName = "Alice"
        customer.LastName = "Smith"
        customer.DateOfBirth = New Date(1985, 8, 25)
        customer.Gender = "Female"
        customer.CustomerID = "123456"

        Console.WriteLine("Person's Full Name: " & person.FullName)
        Console.WriteLine("Customer's Full Name: " & customer.FullName)
        Console.WriteLine("Customer ID: " & customer.CustomerID)

        Console.ReadLine()
    End Sub
End Module
