﻿Imports System.Text.RegularExpressions

Public Class Form1
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim regex As Regex = New Regex("^[\w-]+(\.[\w-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,4})$")
        Dim isValid As Boolean = regex.IsMatch(TextBox1.Text.Trim)
        If Not isValid Then
            ErrorProvider1.SetError(TextBox1, "Invalid Email")
        Else
            ErrorProvider1.Clear()
            MsgBox("Valid Email")
        End If
    End Sub
End Class
