﻿Module Module1
    Public Class Bank
        Dim EmployeeId As Integer
        Dim EmployeeName As String
        Dim DepartmentName As String
        Public Sub New()
            EmployeeId = 121
            EmployeeName = "Vinay Prakash More."
            DepartmentName = "Computer Engineering."
        End Sub
        Public Sub Display()
            Console.WriteLine("Employee Id =" & EmployeeId)
            Console.WriteLine("Employee Name =" & EmployeeName)
            Console.WriteLine("Department Name =" & DepartmentName)
        End Sub
    End Class
    Sub Main()
        Dim b1 As Bank
        b1 = New Bank()
        b1.Display()
        Console.ReadLine()
    End Sub
End Module
