﻿Imports System.Console
Module Module1
    Sub Main()
        Dim message As String
        WriteLine("Enter the message to display:")
        message = ReadLine()
        Dim displayMessage As New DisplayMessage(message)
        displayMessage.Show()
    End Sub
End Module
Public Class DisplayMessage
    Private _message As String
    Public Sub New(ByVal message As String)
        _message = message
    End Sub

    Public Sub Show()
        WriteLine(_message)
        Read()
    End Sub
End Class