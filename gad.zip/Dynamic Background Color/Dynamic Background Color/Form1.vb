﻿Imports System.Windows.Forms

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim button1 As New Button()
        button1.Text = "Wheat"
        button1.Location = New Point(50, 50)
        AddHandler button1.Click, AddressOf ChangeBackgroundColor
        Dim button2 As New Button()
        button2.Text = "Gray"
        button2.Location = New Point(150, 50)
        AddHandler button2.Click, AddressOf ChangeBackgroundColor
        Me.Controls.Add(button1)
        Me.Controls.Add(button2)
    End Sub
    Private Sub ChangeBackgroundColor(sender As Object, e As EventArgs)
        Dim buttonClicked As Button = CType(sender, Button)
        Select Case buttonClicked.Text
            Case "Wheat"
                Me.BackColor = Color.Wheat
            Case "Gray"
                Me.BackColor = Color.Gray
        End Select
    End Sub
End Class
