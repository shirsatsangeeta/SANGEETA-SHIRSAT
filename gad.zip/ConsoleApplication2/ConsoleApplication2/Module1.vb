﻿Module Module1
    Sub Main()
        Console.WriteLine("Welcome to the Visual Basic Quiz Program!")
        Console.WriteLine("Please answer the following questions:")

        ' Question 1
        Console.WriteLine("Question 1: Which method puts the cursor on the next line on the screen?")
        Console.WriteLine("a) Console.WriteLine")
        Console.WriteLine("b) Console.Write")
        Console.Write("Your answer: ")
        Dim answer1 As String = Console.ReadLine()

        ' Question 2
        Console.WriteLine("Question 2: What is the default name of the Module created in Visual Basic with the console template?")
        Console.WriteLine("a) Program.cs")
        Console.WriteLine("b) Program.vb")
        Console.WriteLine("c) program.vb")
        Console.Write("Your answer: ")
        Dim answer2 As String = Console.ReadLine()

        ' Question 3
        Console.WriteLine("Question 3: What parts of your program should match?")
        Console.WriteLine("a) Module and first part of filename")
        Console.WriteLine("b) Subroutine and Module name")
        Console.Write("Your answer: ")
        Dim answer3 As String = Console.ReadLine()

        ' Displaying Results
        Console.WriteLine("Here are your answers:")
        Console.WriteLine("Question 1: Your answer was " & answer1)
        Console.WriteLine("Question 2: Your answer was " & answer2)
        Console.WriteLine("Question 3: Your answer was " & answer3)

        Console.WriteLine("Thank you for taking the quiz!")
        Console.ReadLine()
    End Sub
End Module
