﻿
Module Module1
    Class Example
        Private _value As Integer
        Public Sub New()
            _value = 2
        End Sub
        Public Function Value() As Integer
            Return _value * 2
        End Function
    End Class
    Sub Main()
        Dim x As New Example()
        Console.WriteLine(x.Value())
        Console.ReadLine()
    End Sub
End Module