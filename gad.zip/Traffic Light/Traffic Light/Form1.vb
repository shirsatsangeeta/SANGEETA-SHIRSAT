﻿Public Class Form1
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If RectangleShape190.Visible Then
            RectangleShape190.Visible = False
            RectangleShape191.Visible = True
            RectangleShape192.Visible = False
            RectangleShape193.Visible = True
            RectangleShape194.Visible = False
            RectangleShape195.Visible = True
            RectangleShape196.Visible = False
            RectangleShape197.Visible = True
            RectangleShape198.Visible = False
            RectangleShape199.Visible = True
        Else
            RectangleShape190.Visible = True
            RectangleShape191.Visible = False
            RectangleShape192.Visible = True
            RectangleShape193.Visible = False
            RectangleShape194.Visible = True
            RectangleShape195.Visible = False
            RectangleShape196.Visible = True
            RectangleShape197.Visible = False
            RectangleShape198.Visible = True
            RectangleShape199.Visible = False
        End If
        If RectangleShape190.Visible Then
            RectangleShape200.Visible = False
            RectangleShape201.Visible = True
            RectangleShape202.Visible = False
            RectangleShape203.Visible = True
            RectangleShape204.Visible = False
            RectangleShape205.Visible = True
         Else
            RectangleShape200.Visible = True
            RectangleShape201.Visible = False
            RectangleShape202.Visible = True
            RectangleShape203.Visible = False
            RectangleShape204.Visible = True
            RectangleShape205.Visible = False
             End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If OvalShape1.Visible = True Then
            OvalShape1.Visible = False
            OvalShape2.Visible = True
            OvalShape3.Visible = False
        ElseIf OvalShape2.Visible = True Then
            OvalShape1.Visible = False
            OvalShape2.Visible = False
            OvalShape3.Visible = True
        Else
            OvalShape1.Visible = True
            OvalShape2.Visible = False
            OvalShape3.Visible = False
        End If
    End Sub
End Class
