﻿Module Module1
    Sub Main()
        Dim n As Integer
        Console.Write("Enter the number of terms in Fibonacci series: ")
        n = Integer.Parse(Console.ReadLine())
        Console.WriteLine("Fibonacci series up to {0} terms:", n)
        For i As Integer = 0 To n - 1
            Console.Write(Fibonacci(i) & " ")
        Next
        Console.ReadLine()
    End Sub
    Function Fibonacci(ByVal n As Integer) As Integer
        If n <= 1 Then
            Return n
        Else
            Return Fibonacci(n - 1) + Fibonacci(n - 2)
        End If
    End Function
End Module
