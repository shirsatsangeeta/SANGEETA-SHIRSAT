﻿Public Class Booksale
    Sub New()
        Console.WriteLine("My Base Class")
    End Sub
End Class
Public Class Module1
    Inherits Booksale
    Sub New()
        MyBase.New()
        Console.WriteLine("My child Class")
    End Sub
End Class
