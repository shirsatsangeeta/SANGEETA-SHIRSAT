﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num As Integer
        If Integer.TryParse(TextBox1.Text, num) Then
            Dim temp, sum, remainder, factorial As Integer
            temp = num
            sum = 0
            While temp > 0
                remainder = temp Mod 10
                factorial = 1
                For i As Integer = 1 To remainder
                    factorial *= i
                Next
                sum += factorial
                temp \= 10
            End While
            If sum = num Then
                Label3.Text = "It is a Strong no"
            Else
                Label3.Text = "It is not a Strong no"
            End If
        Else
            MessageBox.Show("Please enter a valid integer.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
End Class
