﻿Module Module1
    Sub Main()
        Console.WriteLine()
        Console.WriteLine()
        Console.WriteLine("               Main program to print even-odd numbers between 1-50")
        Console.WriteLine()
        Console.WriteLine()
        Dim num As Integer = 1
        Console.WriteLine("Even numbers between 1-50:")
        While num <= 50
            If num Mod 2 = 0 Then
                Console.Write(num & " ")
            End If
            num += 1
        End While

        num = 1
        Console.WriteLine(vbCrLf & "Odd numbers between 1-50:")
        While num <= 50
            If num Mod 2 <> 0 Then
                Console.Write(num & " ")
            End If
            num += 1
        End While
        Console.ReadLine()
    End Sub
End Module
