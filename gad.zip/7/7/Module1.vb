﻿Module Module1
    Sub Main()
        Dim sum As Integer = 0
        Dim input As Integer

        Console.WriteLine("Enter numbers (enter -1 to finish): ")
        Do
            Console.Write("Enter a number (-1 to finish): ")
            input = Convert.ToInt32(Console.ReadLine())

            If input <> -1 Then
                sum += input
            End If
        Loop While input <> -1

        Console.WriteLine("The sum of all numbers entered is: " & sum)
    End Sub
End Module
