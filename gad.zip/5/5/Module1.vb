﻿Module Module1

    Sub Main(args As String())
        Console.Write("Please enter a number: ")
        Dim number As Integer
        If Integer.TryParse(Console.ReadLine(), number) Then
            If number < 100 Then
                Console.WriteLine("Small")
            ElseIf number > 200 Then
                Console.WriteLine("Large")
            Else
                Console.WriteLine("Medium")
            End If
        Else
            Console.WriteLine("Invalid input. Please enter a valid number.")
        End If
    End Sub
End Module
