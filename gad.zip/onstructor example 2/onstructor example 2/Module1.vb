﻿Imports System.Console
Module Module1
    Sub Main()
        Dim obj As New Destroy()
    End Sub
End Module
Public Class Destroy
    Protected Overrides Sub Finalize()
        Write("VB.NET")
        ReadLine()
    End Sub
End Class
