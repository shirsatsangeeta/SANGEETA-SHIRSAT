﻿Public Class Faculty
    Public Property Name As String
    Public Property Department As String

    Public Sub New(name As String, department As String)
        Me.Name = name
        Me.Department = department
    End Sub

    Public Overridable Sub Display()
        Console.WriteLine("Name: " & Name & ", Department: " & Department)
    End Sub
End Class
Public Class Student
    Inherits Faculty
    Public Property StudentID As Integer

    Public Sub New(name As String, department As String, studentID As Integer)
        MyBase.New(name, department)
        Me.StudentID = studentID
    End Sub

    Public Overrides Sub Display()
        Console.WriteLine("Name: " & Name & ", Department: " & Department & ", Student ID: " & StudentID)
    End Sub
End Class

Module Module1
    Sub Main(args As String())
        Dim facultyMember As New Faculty("John Doe", "Computer Science")
        Dim studentMember As New Student("Jane Smith", "Electrical Engineering", 123456)
        Console.WriteLine("Faculty Information:")
        facultyMember.Display()
        Console.WriteLine("Student Information:")
        studentMember.Display()
        Console.ReadLine()
    End Sub
End Module