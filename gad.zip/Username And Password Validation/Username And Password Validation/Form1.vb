﻿Public Class LoginForm
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim username As String = TextBox1.Text.Trim()
        Dim password As String = TextBox2.Text.Trim()
        ErrorProvider1.Clear()
        If String.IsNullOrWhiteSpace(username) Then
            ErrorProvider1.SetError(TextBox1, "!")
            Exit Sub
        End If
        If String.IsNullOrWhiteSpace(password) Then
            ErrorProvider1.SetError(TextBox2, "!")
            Exit Sub
        End If
        If username = "admin" Then
            If password = "password" Then
                ErrorProvider1.Clear()
                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                ErrorProvider1.SetError(TextBox2, "Invalid Password")
                MessageBox.Show("Invalid Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Else
            ErrorProvider1.SetError(TextBox1, "Invalid Username")
            MessageBox.Show("Invalid username ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub












End Class
