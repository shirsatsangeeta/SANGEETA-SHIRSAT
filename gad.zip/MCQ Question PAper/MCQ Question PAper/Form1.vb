﻿Public Class Form1
    Dim score As Decimal = 0

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        score = 0
        If RadioButton5.Checked Then
            score += 5
            If CheckBox2.Checked Then
                score += 5
            End If
            If CheckBox3.Checked Then
                score += 5
            End If
            If CheckBox4.Checked Then
                score += 5
            End If
        End If
        MessageBox.Show("Your score: " & score & "/ 20")
    End Sub
End Class
