﻿Module Module1
    Sub Main()
        Console.Write("Enter a number: ")
        Dim num As Integer = Convert.ToInt32(Console.ReadLine())

        Dim sum As Integer = 0
        For i As Integer = 1 To num
            sum += i
        Next

        Console.WriteLine("The sum of all values from 1 to " & num & " is: " & sum)
    End Sub
End Module
