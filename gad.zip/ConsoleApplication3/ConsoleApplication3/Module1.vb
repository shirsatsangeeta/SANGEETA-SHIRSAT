﻿Module Module1
    Sub Main()
        Dim num As Double
        For num = 3.5 To 8.5 Step 0.5
            Console.WriteLine(num)
        Next
        Console.ReadLine()
    End Sub
End Module
