﻿Module Module1
    Sub Main()
        Console.Write("Enter a number: ")
        Dim number As Integer = Integer.Parse(Console.ReadLine())
        ReverseNumber(number)
        Console.ReadLine()
    End Sub
    Sub ReverseNumber(ByVal num As Integer)
        Dim reverse As Integer = 0
        While num > 0
            Dim remainder As Integer = num Mod 10
            reverse = (reverse * 10) + remainder
            num \= 10
        End While
        Console.WriteLine("The reverse of the number is: " & reverse)
    End Sub
End Module
