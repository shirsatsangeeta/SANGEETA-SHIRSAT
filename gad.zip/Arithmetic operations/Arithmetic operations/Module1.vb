﻿Module Module1
    Sub Main()
        Dim num1, num2 As Double
        Dim operation As Char
        Dim result As Double = 0

        Console.WriteLine("Enter first number: ")
        Double.TryParse(Console.ReadLine(), num1)

        Console.WriteLine("Enter second number: ")
        Double.TryParse(Console.ReadLine(), num2)

        Console.WriteLine("Enter the operation (+, -, *, /): ")
        Char.TryParse(Console.ReadLine(), operation)

        Select Case operation
            Case "+"
                result = num1 + num2
            Case "-"
                result = num1 - num2
            Case "*"
                result = num1 * num2
            Case "/"
                If num2 <> 0 Then
                    result = num1 / num2
                Else
                    Console.WriteLine("Cannot divide by zero.")
                End If
            Case Else
                Console.WriteLine("Invalid operation.")
        End Select

        Console.WriteLine("Result: " & result)
        Console.ReadLine()
    End Sub
End Module
