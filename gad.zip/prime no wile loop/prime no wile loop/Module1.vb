﻿Module Module1
    Sub Main()
        Console.WriteLine()
        Console.WriteLine()
        Console.WriteLine("         Main program to print prime numbers between 1-100")
        Console.WriteLine()
        Console.WriteLine()
        Dim num As Integer = 1
        While num <= 100
            Dim isPrime As Boolean = True
            If num > 1 Then
                Dim i As Integer = 2
                While i <= num / 2
                    If num Mod i = 0 Then
                        isPrime = False
                        Exit While
                    End If
                    i += 1
                End While
            Else
                isPrime = False
            End If

            If isPrime Then
                Console.Write(num & " ")
            End If

            num += 1
        End While
        Console.ReadLine()
    End Sub
End Module
