﻿Module Module1
    Sub Main(args As String())
        Console.WriteLine("Welcome to Coursera")
        Console.Write("Please enter your name: ")
        Dim name As String = Console.ReadLine()
        Console.WriteLine("Welcome to Coursera " & name)
        Console.ReadLine()
    End Sub
End Module
