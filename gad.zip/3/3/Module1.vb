﻿Module Module1
    Sub Main(args As String())
        Console.Write("Please enter your salary: ")
        Dim salary As Decimal
        If Decimal.TryParse(Console.ReadLine(), salary) Then
            Dim formattedSalary As String = salary.ToString("#,##0.00")
            Console.WriteLine("Formatted salary: " & formattedSalary)
        Else
            Console.WriteLine("Invalid input. Please enter a valid salary.")
        End If
    End Sub
End Module
