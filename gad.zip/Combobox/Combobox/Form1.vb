﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Average As Double
        Average = ((Val(ComboBox1.SelectedItem) + Val(ComboBox2.SelectedItem)) / 2)
        Label4.Text = Average.ToString()
    End Sub
End Class
