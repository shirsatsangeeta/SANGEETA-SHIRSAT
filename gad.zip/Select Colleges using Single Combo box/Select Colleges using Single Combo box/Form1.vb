﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.SelectedItem IsNot Nothing Then
            MessageBox.Show("Selected College: " & ComboBox1.SelectedItem.ToString())
        Else
            MessageBox.Show("Please select a college.")
        End If
    End Sub
End Class
