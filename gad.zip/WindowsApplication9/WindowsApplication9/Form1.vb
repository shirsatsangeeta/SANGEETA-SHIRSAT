﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Panel1.BackColor = Color.Yellow
    End Sub
End Class
