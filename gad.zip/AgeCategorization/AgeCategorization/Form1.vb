﻿Public Class Form1

  
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Select Case Val(TextBox1.Text)
            Case 0 To 5
                TextBox2.Text = "You are a toddler."
            Case 6 To 12
                TextBox2.Text = "You are a child."
            Case 13 To 19
                TextBox2.Text = "You are a teenager."
            Case 20 To 59
                TextBox2.Text = "You are an adult."
            Case Else
                TextBox2.Text = "You are a senior citizen."
        End Select


    End Sub
End Class
