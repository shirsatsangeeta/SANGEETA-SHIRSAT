﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num As Integer = 10 ' Number of iterations
        Dim i As Integer ' Loop counter

        ' Hide all mole images initially
        For Each picBox As PictureBox In {PictureBox7, PictureBox8, PictureBox9, PictureBox10, PictureBox11, PictureBox12}
            picBox.Visible = False
        Next

        ' Array to hold PictureBoxes
        Dim ele(5) As PictureBox

        ' Assign PictureBoxes to array
        ele(0) = PictureBox7
        ele(1) = PictureBox8
        ele(2) = PictureBox9
        ele(3) = PictureBox10
        ele(4) = PictureBox11
        ele(5) = PictureBox12

        ' Loop to make mole images randomly appear
        For i = 1 To num ' Start loop from 1 (not 0) to num
            ' Generate two random numbers to determine which mole images will appear
            Dim r1 As Integer = CInt(Int(6 * Rnd())) ' Generates random number between 0 and 5
            Dim r2 As Integer = CInt(Int(6 * Rnd()))

            ' Show mole images at random PictureBoxes
            ele(r1).Visible = True
            ele(r2).Visible = True

            ' Wait for a short time before hiding the mole images again (optional)
            System.Threading.Thread.Sleep(500) ' Wait for 500 milliseconds (0.5 seconds)

            ' Hide mole images again
            ele(r1).Visible = False
            ele(r2).Visible = False
        Next i
    End Sub
End Class
