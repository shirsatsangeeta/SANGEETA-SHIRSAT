﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.SelectedItem IsNot Nothing Then
            ListBox1.Items.Add(ComboBox1.SelectedItem)
            ComboBox1.Items.Remove(ComboBox1.SelectedItem)
        End If
    End Sub
End Class
