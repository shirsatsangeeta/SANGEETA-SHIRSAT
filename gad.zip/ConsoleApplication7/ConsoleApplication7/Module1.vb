﻿Imports System

Public Class Booksale
    Sub New()
        Console.WriteLine("My Base Class")
    End Sub
End Class

Public Class studentbo
    Inherits Booksale
    Sub New()
        MyBase.New()
        Console.WriteLine("My child Class")
    End Sub
End Class

Module Module1
    Sub Main()
        Dim student As New studentbo()
        Console.ReadLine()
    End Sub
End Module
