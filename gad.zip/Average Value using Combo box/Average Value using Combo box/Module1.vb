﻿Module Module1
    Public Class Volume
        Dim length As Integer
        Dim breadth As Integer
        Dim height As Integer
        Public Function Getdata()
            Console.Write("Enter the Length of the Rectangle: ")
            length = Console.ReadLine()
            Console.Write("Enter the Breadth of the Rectangle: ")
            breadth = Console.ReadLine()
            Console.Write("Enter the Height of the Rectangle: ")
            height = Console.ReadLine()
            Return 0
        End Function
        Public Function Display()
            Dim volume As Integer
            volume = length * breadth * height
            Console.WriteLine()
            Console.WriteLine("Volume of Box ( l * b * h )= " & volume & " cubic unite")
            Return 0
        End Function
    End Class
    Sub Main()
        Dim v1 As Volume
        v1 = New Volume
        v1.Getdata()
        v1.Display()
        Console.ReadKey()
    End Sub

End Module
