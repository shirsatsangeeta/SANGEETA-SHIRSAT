﻿Module Module1
    Sub Main()
        Dim num1 As Integer = 10
        Dim num2 As Integer = 5

        AddNumbers(num1, num2)

        SubtractNumbers(num1, num2)

        Console.ReadLine()
    End Sub

    Sub AddNumbers(ByVal a As Integer, ByVal b As Integer)
        Dim result As Integer = a + b
        Console.WriteLine("The sum of {0} and {1} is {2}", a, b, result)
    End Sub

    Sub SubtractNumbers(ByVal a As Integer, ByVal b As Integer)
        Dim result As Integer = a - b
        Console.WriteLine("The difference between {0} and {1} is {2}", a, b, result)
    End Sub
End Module
