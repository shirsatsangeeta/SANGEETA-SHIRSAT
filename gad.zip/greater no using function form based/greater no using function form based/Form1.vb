﻿Public Class MainForm
    Private Sub FindMaxButton_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num1 As Integer
        Dim num2 As Integer
        If Integer.TryParse(TextBox1.Text, num1) AndAlso Integer.TryParse(TextBox2.Text, num2) Then
            MessageBox.Show("The maximum number is: " & FindMax(num1, num2))
        Else
            MessageBox.Show("Invalid input. Please enter valid integers.")
        End If
    End Sub
    Private Function FindMax(ByVal num1 As Integer, ByVal num2 As Integer) As Integer
        If num1 > num2 Then
            Return num1
        Else
            Return num2
        End If
    End Function
End Class
