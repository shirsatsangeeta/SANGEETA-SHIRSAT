﻿Module Module1
    Sub Main()
        Dim input As String = "abcdefghijklmnopqrstuvwxyz"
        Dim vowelCount As Integer = 0

        For Each letter As Char In input
            Select Case Char.ToLower(letter)
                Case "a", "e", "i", "o", "u"
                    vowelCount += 1
            End Select
        Next

        Console.WriteLine("Number of vowels in A-to-Z alphabets: " & vowelCount)
        Console.ReadLine()
    End Sub
End Module
