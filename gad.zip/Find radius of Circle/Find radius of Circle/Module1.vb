﻿Imports System.Console

Module Module1
    Sub Main()
        Dim radius As Double
        WriteLine("Enter the radius of the circle:")
        If Double.TryParse(ReadLine(), radius) Then
            Dim circle As New Circle(radius)
            Dim area As Double = circle.CalculateArea()
            WriteLine("The area of the circle with radius " & radius & " is: " & area)
            Read()
        Else
            WriteLine("Invalid input for radius. Please enter a valid number.")
        End If
    End Sub
End Module

Public Class Circle
    Private radius1 As Double

    Public Sub New(ByVal radius As Double)
        radius1 = radius
    End Sub

    Public Function CalculateArea() As Double
        Return 3.14 * radius1 * radius1
    End Function
End Class
