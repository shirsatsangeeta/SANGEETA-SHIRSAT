﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.Items.Add("Chess")
        ComboBox1.Items.Add("Monopoly")
        ComboBox1.Items.Add("Snake and Ladder")
        ComboBox1.Items.Add("Badminton")
        ComboBox1.Items.Add("Football")
        ComboBox1.Items.Add("Basketball")

        ListBox1.Items.Add("Indoor Games")
        ListBox1.Items.Add("Outdoor Games")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ListBox3.Items.Add(ComboBox1.SelectedItem)
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        ListBox2.Items.Add(" " + ListBox1.SelectedItem.ToString())
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ListBox3.Items.RemoveAt(ListBox3.SelectedIndex())
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ListBox3.Items.Clear()
    End Sub

   
End Class
