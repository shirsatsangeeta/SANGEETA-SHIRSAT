﻿Module Module1

    Sub Main()
        Console.Write("   Fibonacci Series:")
        Console.ReadLine()
        Dim n, num1, num2, num3, i As Integer
        Console.Write("  Enter the Range for the Fibonacci Series: ")
        n = Val(Console.ReadLine)
        i = 0
        num1 = 0
        num2 = 1
        Console.Write("   " & num1 & " , " & num2)
        While (i < n - 1)
            num3 = num1 + num2
            Console.Write(", " & num3)
            num1 = num2
            num2 = num3
            i = i + 1
        End While
        Console.ReadLine()
    End Sub

End Module
