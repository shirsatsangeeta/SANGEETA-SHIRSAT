﻿Imports System.Text.RegularExpressions

Public Class Form1
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim inputDate As Date
        If Date.TryParse(TextBox1.Text.Trim, inputDate) Then
            ErrorProvider1.Clear()
            MsgBox("Valid Date: " & inputDate.ToString("dd/MM/yyyy"))
        Else
            ErrorProvider1.SetError(TextBox1, "Invalid Date")
        End If
    End Sub
End Class