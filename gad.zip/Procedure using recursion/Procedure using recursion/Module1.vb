﻿Module Module1
    Sub Main()
        Dim num As Integer = 5
        Dim factorialResult As Integer = Factorial(num)
        Console.WriteLine("Factorial of {0} is {1}", num, factorialResult)
        Console.ReadLine()
    End Sub
    Function Factorial(ByVal n As Integer) As Integer
        If n = 0 Then
            Return 1
        Else
            Return n * Factorial(n - 1)
        End If
    End Function
End Module
