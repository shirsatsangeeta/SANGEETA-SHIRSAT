﻿Module Module1
    Public Class B
        Dim x As Integer
        Public Sub New(ByVal b As Integer)
            x = b
        End Sub
        Public Function Display() As B
            Console.WriteLine("Value of X = " & x)
            Return Me
        End Function
    End Class

    Public Class C
        Dim x As Integer
        Public Sub New(ByVal b As Integer)
            x = b
        End Sub
        Public Function Display() As C
            Console.WriteLine("Value of X = " & x)
            Return Me
        End Function
    End Class

    Sub Main()
        Dim b As B = New B(5)
        b = b.Display()

        Dim c As C = New C(5)
        c = c.Display()
        Console.ReadKey()
    End Sub
End Module
